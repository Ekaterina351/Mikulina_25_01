package footprints;

public enum GameState {
    GAME_IS_WON,
    GAME_IS_LOST,
    GAME_IS_ON,
}
