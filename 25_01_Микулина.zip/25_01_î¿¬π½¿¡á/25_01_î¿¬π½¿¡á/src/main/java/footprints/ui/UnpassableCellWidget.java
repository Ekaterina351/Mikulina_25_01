package footprints.ui;

import java.awt.*;

public class UnpassableCellWidget extends CellWidget {

    public UnpassableCellWidget() {
        super(Color.RED);
    }
}
