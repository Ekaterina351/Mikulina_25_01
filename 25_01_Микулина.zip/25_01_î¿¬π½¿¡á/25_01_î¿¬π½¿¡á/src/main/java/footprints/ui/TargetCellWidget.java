package footprints.ui;

import java.awt.*;

public class TargetCellWidget extends CellWidget {

    public TargetCellWidget() {
        super(Color.GREEN);
    }
}
