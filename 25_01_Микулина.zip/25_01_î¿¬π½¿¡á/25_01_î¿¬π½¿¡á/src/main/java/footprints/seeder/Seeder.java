package footprints.seeder;

import footprints.field.Field;

public abstract class Seeder {
    protected final Field _field;

    public Seeder(Field field) {
        _field = field;
        run();
    }

    public Field getField() {
        return _field;
    }

    private void run() {
        seedPlayer(_field);
        seedKeys(_field);
    }

    abstract protected void seedPlayer(Field field);

    abstract protected void seedKeys(Field field);
}
