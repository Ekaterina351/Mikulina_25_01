package footprints;

import footprints.events.TargetCellActionEvent;
import footprints.events.TargetCellActionListener;
import footprints.field.TargetCell;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TargetCellTest {
    private TargetCell _targetCell;
    private Player _player;
    private int _eventCount;

    private class EventListener implements TargetCellActionListener {
        @Override
        public void playerAtTargetCell(@NotNull TargetCellActionEvent event) {
            _eventCount += 1;
        }
    }

    @BeforeEach
    void testSetup() {
        _targetCell = new TargetCell();
        _targetCell.addTargetActionListener(new EventListener());
        _player = new Player();
        _eventCount = 0;
    }

    @Test
    public void test_setPlayer_onePlayer() {
        int expectedEventCount = 1;

        assertTrue(_targetCell.setPlayer(_player));
        assertEquals(expectedEventCount, _eventCount);
        assertEquals(_targetCell, _player.getPosition());
    }

    @Test
    public void test_setPlayer_cannotSetMoreThanOne() {
        assertTrue(_targetCell.setPlayer(_player));
        assertFalse(_targetCell.setPlayer(_player));
    }
}