package footprints;

import footprints.field.AbstractCell;
import footprints.field.PassableCell;
import footprints.items.Key;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PassableCellTest {
    PassableCell _passableCell;

    @BeforeEach
    public void testSetup() {
        _passableCell = new PassableCell();
    }

    @Test
    public void test_create_empty() {
        assertFalse(_passableCell.hasFootPrint());
        assertNull(_passableCell.whoLeftFootPrint());
        assertFalse(_passableCell.hasKey());
        assertNull(_passableCell.getKey());
        assertNull(_passableCell.extractKey());
    }

    @Test
    public void test_setPlayer_onePlayer() {
        Player player = new Player();

        assertTrue(_passableCell.setPlayer(player));
        assertTrue(_passableCell.hasFootPrint());
        assertEquals(player, _passableCell.whoLeftFootPrint());
    }

    @Test
    public void test_extractPlayer_onePlayer() {
        Player player = new Player();

        assertTrue(_passableCell.setPlayer(player));
        assertEquals(player, _passableCell.getPlayer());

        assertEquals(player, _passableCell.extractPlayer());
        assertFalse(_passableCell.hasPlayer());
    }

    @Test
    public void test_setKey_oneKey() {
        Key key = new Key();

        assertTrue(_passableCell.setKey(key));
        assertTrue(_passableCell.hasKey());
        assertEquals(key, _passableCell.getKey());
    }

    @Test
    public void test_extractKey_oneKey() {
        Key key = new Key();

        assertTrue(_passableCell.setKey(key));
        assertTrue(_passableCell.hasKey());
        assertEquals(key, _passableCell.getKey());

        assertEquals(key, _passableCell.extractKey());
        assertFalse(_passableCell.hasKey());
    }

    @Test
    public void test_setNeighbor_setSeveralNeighbors() {
        AbstractCell cell1 = new PassableCell();
        AbstractCell cell2 = new PassableCell();
        _passableCell.setNeighbor(cell1, Direction.SOUTHEAST);
        _passableCell.setNeighbor(cell2, Direction.SOUTH);

        assertEquals(_passableCell, cell1.getNeighbor(Direction.NORTHWEST));
        assertEquals(_passableCell, cell2.getNeighbor(Direction.NORTH));
        assertEquals(cell1, _passableCell.getNeighbor(Direction.SOUTHEAST));
        assertEquals(cell2, _passableCell.getNeighbor(Direction.SOUTH));
        assertEquals(cell1, cell2.getNeighbor(Direction.NORTHEAST));
        assertEquals(cell2, cell1.getNeighbor(Direction.SOUTHWEST));
    }
}