package footprints;

import footprints.events.PlayerActionEvent;
import footprints.events.PlayerActionListener;
import footprints.field.AbstractCell;
import footprints.field.PassableCell;
import footprints.field.TargetCell;
import footprints.items.Key;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {
    private enum EVENT { PLAYER_MOVED, PLAYER_GOT_KEY }

    private final List<EVENT> _events = new ArrayList<>();
    private final List<EVENT> _expectedEvents = new ArrayList<>();

    private class EventListener implements PlayerActionListener {

        @Override
        public void playerMoved(@NotNull PlayerActionEvent event) {
            _events.add(EVENT.PLAYER_MOVED);
        }

        @Override
        public void playerGotKey(@NotNull PlayerActionEvent event) {
            _events.add(EVENT.PLAYER_GOT_KEY);
        }
    }

    private final Direction _direction = Direction.NORTH;
    private Player _player;

    @BeforeEach
    public void testSetup() {
        _events.clear();
        _expectedEvents.clear();

        _player = new Player();
        _player.addPlayerActionListener(new EventListener());
    }

    @Test
    public void test_move_betweenPassableCells() {
        AbstractCell cell = new PassableCell();
        AbstractCell neighborCell = new PassableCell();
        cell.setNeighbor(neighborCell, Direction.NORTH);
        cell.setPlayer(_player);

        _expectedEvents.add(EVENT.PLAYER_MOVED);

        assertTrue(_player.move(Direction.NORTH));
        assertEquals(_player, neighborCell.getPlayer());
        assertEquals(neighborCell, _player.getPosition());
        assertNull(cell.getPlayer());
        assertEquals(_expectedEvents, _events);
    }



    @Test
    public void test_move_moveToTargetCell() {
        AbstractCell cell = new PassableCell();
        AbstractCell neighborCell = new TargetCell();
        cell.setNeighbor(neighborCell, Direction.NORTH);
        cell.setPlayer(_player);

        _expectedEvents.add(EVENT.PLAYER_MOVED);

        assertTrue(_player.move(Direction.NORTH));
        assertEquals(_player, neighborCell.getPlayer());
        assertEquals(neighborCell, _player.getPosition());
        assertNull(cell.getPlayer());
        assertEquals(_expectedEvents, _events);
    }

    @Test
    public void test_move_moveToCellWithKey() {
        AbstractCell cell = new PassableCell();
        PassableCell neighborCell = new PassableCell();
        cell.setNeighbor(neighborCell, Direction.NORTH);
        cell.setPlayer(_player);
        Key key = new Key();
        neighborCell.setKey(key);

        _expectedEvents.add(EVENT.PLAYER_MOVED);
        _expectedEvents.add(EVENT.PLAYER_GOT_KEY);

        assertTrue(neighborCell.hasKey());
        assertEquals(key, neighborCell.getKey());
        assertTrue(_player.move(Direction.NORTH));
        assertEquals(_player, neighborCell.getPlayer());
        assertEquals(1, _player.getFoundKeys().size());
        assertEquals(neighborCell, _player.getPosition());
        assertNull(cell.getPlayer());
        assertFalse(neighborCell.hasKey());
        assertNull(neighborCell.getKey());
        assertEquals(_expectedEvents, _events);
    }
}