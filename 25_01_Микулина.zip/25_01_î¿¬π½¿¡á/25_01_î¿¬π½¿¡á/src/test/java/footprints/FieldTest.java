package footprints;

import footprints.field.AbstractCell;
import footprints.field.Field;
import footprints.field.PassableCell;
import footprints.field.TargetCell;
import footprints.items.Key;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FieldTest {

    private class SmallField extends Field {

        public SmallField() {
            buildField();
        }

        @Override
        protected AbstractCell buildField() {
            PassableCell startCell = new PassableCell();
            PassableCell cell1 = new PassableCell();
            PassableCell cell2 = new PassableCell();
            TargetCell target = new TargetCell();
            startCell.setNeighbor(cell1, Direction.NORTH);
            cell1.setNeighbor(cell2, Direction.NORTH);
            cell2.setNeighbor(target, Direction.NORTH);
            return startCell;
        }
    }

    private Field _field;


    @BeforeEach
    public void testSetup() {
        _field = new SmallField();
    }

    @Test
    public void test_create_defaultField() {
        assertEquals(0, _field.getRemainingKeys().size());
        assertNull(_field.getPlayer());
    }

    @Test
    public void test_getRemainingKeys_oneKey() {
        Key key = new Key();
        ((PassableCell) _field.getStartCell()).setKey(key);
        assertEquals(1, _field.getRemainingKeys().size());
    }

    @Test
    public void test_getPlayer_onePlayer() {
        Player player = new Player();
        _field.getStartCell().setPlayer(player);
        assertEquals(player, _field.getPlayer());
    }
}